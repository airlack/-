/* 2024-05-31 01:20:47 [12 ms] */ 
CREATE DATABASE CSManagementSystem;
/* 2024-05-31 01:20:49 [3 ms] */ 
USE CSManagementSystem;
/* 2024-05-31 01:20:51 [40 ms] */ 
CREATE TABLE Club (
    ClubID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(255) NOT NULL,
    CreationDate DATE NOT NULL,
    Region VARCHAR(255) NOT NULL
);
/* 2024-05-31 01:20:53 [54 ms] */ 
CREATE TABLE Team (
    Name VARCHAR(255) PRIMARY KEY,
    ClubID INT NOT NULL,
    Region VARCHAR(255) NOT NULL,
    FormationDate DATE NOT NULL,
    FOREIGN KEY (ClubID) REFERENCES Club(ClubID)
);
/* 2024-05-31 01:20:55 [60 ms] */ 
CREATE TABLE Member (
    MemberID INT PRIMARY KEY AUTO_INCREMENT,
    TeamName VARCHAR(255) NOT NULL,
    Name VARCHAR(255) NOT NULL,
    Role VARCHAR(255) NOT NULL,
    Nationality VARCHAR(255) NOT NULL,
    JoinDate DATE NOT NULL,
    Age INT NOT NULL,
    FOREIGN KEY (TeamName) REFERENCES Team(Name)
);
/* 2024-05-31 01:21:53 [42 ms] */ 
CREATE TABLE Matches (
    Number INT PRIMARY KEY AUTO_INCREMENT,
    Date DATE NOT NULL,
    Level VARCHAR(255) NOT NULL
);
/* 2024-05-31 01:21:59 [42 ms] */ 
CREATE TABLE Sponsor (
    Name VARCHAR(255) PRIMARY KEY,
    Industry VARCHAR(255) NOT NULL,
    ContactInfo VARCHAR(255) NOT NULL
);
/* 2024-05-31 01:22:04 [51 ms] */ 
CREATE TABLE StartingMember (
    MemberID INT PRIMARY KEY,
    Starts INT NOT NULL,
    StartingPosition VARCHAR(255) NOT NULL,
    FOREIGN KEY (MemberID) REFERENCES Member(MemberID)
);
/* 2024-05-31 01:22:07 [42 ms] */ 
CREATE TABLE YouthMember (
    MemberID INT PRIMARY KEY,
    TrainingLevel VARCHAR(255) NOT NULL,
    YearJoined INT NOT NULL,
    FOREIGN KEY (MemberID) REFERENCES Member(MemberID)
);
/* 2024-05-31 01:22:11 [53 ms] */ 
CREATE TABLE SubstituteMember (
    MemberID INT PRIMARY KEY,
    SubstituteAppearances INT NOT NULL,
    FOREIGN KEY (MemberID) REFERENCES Member(MemberID)
);
/* 2024-05-31 01:22:16 [63 ms] */ 
CREATE TABLE Sponsorship (
    SponsorName VARCHAR(255),
    ClubID INT,
    PRIMARY KEY (SponsorName, ClubID),
    FOREIGN KEY (SponsorName) REFERENCES Sponsor(Name),
    FOREIGN KEY (ClubID) REFERENCES Club(ClubID)
);
/* 2024-05-31 01:22:28 [55 ms] */ 
CREATE TABLE MatchParticipation (
    MatchNumber INT,
    TeamName VARCHAR(255),
    PRIMARY KEY (MatchNumber, TeamName),
    FOREIGN KEY (MatchNumber) REFERENCES Matches(Number),
    FOREIGN KEY (TeamName) REFERENCES Team(Name)
);
/* 2024-05-31 01:22:40 [29 ms] */ 
INSERT INTO Club (Name, CreationDate, Region) VALUES 
('Team A Club', '2020-01-01', 'Region 1'),
('Team B Club', '2019-05-15', 'Region 2');
/* 2024-05-31 01:22:42 [16 ms] */ 
INSERT INTO Team (Name, ClubID, Region, FormationDate) VALUES 
('Team A', 1, 'Region 1', '2020-01-15'),
('Team B', 2, 'Region 2', '2019-06-01');
/* 2024-05-31 01:22:44 [12 ms] */ 
INSERT INTO Member (TeamName, Name, Role, Nationality, JoinDate, Age) VALUES 
('Team A', 'Alice', 'Player', 'Country 1', '2020-02-01', 20),
('Team B', 'Bob', 'Player', 'Country 2', '2019-07-01', 22);
/* 2024-05-31 19:34:36 [37 ms] */ 
CREATE TABLE Club (
    ClubID INT PRIMARY KEY,
    Name VARCHAR(255) NOT NULL,
    CreationDate DATE NOT NULL,
    Region VARCHAR(255) NOT NULL
);
/* 2024-05-31 19:40:52 [14 ms] */ 
INSERT INTO Club (Name,ClubID, CreationDate, Region) VALUES 
('Team A Club',1, '2020-01-01', 'Region 1'),
('Team B Club',2,'2019-05-15', 'Region 2');
/* 2024-06-01 12:26:36 [1 ms] */ 
USE CSManagementSystem;
/* 2024-06-01 12:26:41 [23 ms] */ 
CREATE TRIGGER before_club_insert
BEFORE INSERT ON Club
FOR EACH ROW
BEGIN
    DECLARE name_count INT;
    SELECT COUNT(*) INTO name_count FROM Club WHERE Name = NEW.Name;
    IF name_count > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Club name must be unique';
    END IF;
END ;
/* 2024-06-01 12:41:39 [1 ms] */ 
USE CSManagementSystem;
/* 2024-06-01 12:41:43 [20 ms] */ 
CREATE PROCEDURE update_club_procedure(
    IN p_club_id INT,
    IN p_name VARCHAR(255),
    IN p_creation_date DATE,
    IN p_region VARCHAR(255)
)
BEGIN
    -- 检查俱乐部名称是否为空
    IF p_name IS NULL OR p_name = '' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Club name cannot be empty';
    ELSE
        -- 更新俱乐部信息
        UPDATE Club
        SET Name = p_name, CreationDate = p_creation_date, Region = p_region
        WHERE ClubID = p_club_id;
    END IF;
END ;
/* 2024-06-01 12:50:59 [2 ms] */ 
USE CSManagementSystem;
/* 2024-06-01 12:51:32 [28 ms] */ 
CREATE PROCEDURE update_member_procedure(
    IN p_member_id INT,
    IN p_team_name VARCHAR(255),
    IN p_name VARCHAR(255),
    IN p_role VARCHAR(255),
    IN p_nationality VARCHAR(255),
    IN p_join_date DATE,
    IN p_age INT
)
BEGIN
    
    IF p_age > 40 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Player age cannot be greater than 40';
    ELSE
        
        UPDATE Member
        SET TeamName = p_team_name, Name = p_name, Role = p_role, Nationality = p_nationality, JoinDate = p_join_date, Age = p_age
        WHERE MemberID = p_member_id;
    END IF;
END;
/* 2024-06-01 13:18:06 [17 ms] */ 
CREATE VIEW ClubMembersView AS
SELECT 
    Club.Name AS ClubName,
    Member.Name AS MemberName,
    Member.Role AS MemberRole
FROM 
    Club
JOIN 
    Team ON Club.ClubID = Team.ClubID
JOIN 
    Member ON Team.Name = Member.TeamName;
/* 2024-06-01 23:52:15 [2 ms] */ 
USE CSManagementSystem;
/* 2024-06-01 23:52:25 [15 ms] */ 
CREATE PROCEDURE update_member_procedure(
    IN p_member_id INT,
    IN p_team_name VARCHAR(255),
    IN p_name VARCHAR(255),
    IN p_role VARCHAR(255),
    IN p_nationality VARCHAR(255),
    IN p_join_date DATE,
    IN p_age INT
)
BEGIN
    -- 检查选手年龄是否超过40岁
    IF p_age > 40 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '成员年龄不能大于40岁';
    ELSE
        -- 更新选手信息
        UPDATE Member
        SET TeamName = p_team_name, Name = p_name, Role = p_role, Nationality = p_nationality, JoinDate = p_join_date, Age = p_age
        WHERE MemberID = p_member_id;
    END IF;
END ;
/* 2024-06-01 23:59:13 [1 ms] */ 
USE CSManagementSystem;
/* 2024-06-01 23:59:16 [13 ms] */ 
INSERT INTO Club (ClubID, Name, CreationDate, Region) VALUES 
(1, 'Team A Club', '2020-01-01', 'Region 1'),
(2, 'Team B Club', '2019-05-15', 'Region 2'),
(3, 'Team C Club', '2018-03-22', 'Region 3'),
(4, 'Team D Club', '2021-04-10', 'Region 1'),
(5, 'Team E Club', '2017-11-30', 'Region 2'),
(6, 'Team F Club', '2019-08-25', 'Region 3'),
(7, 'Team G Club', '2020-09-12', 'Region 1'),
(8, 'Team H Club', '2018-07-19', 'Region 2'),
(9, 'Team I Club', '2017-10-05', 'Region 3'),
(10, 'Team J Club', '2019-12-15', 'Region 1'),
(11, 'Team K Club', '2021-01-01', 'Region 2'),
(12, 'Team L Club', '2020-05-22', 'Region 3'),
(13, 'Team M Club', '2018-09-09', 'Region 1'),
(14, 'Team N Club', '2019-04-16', 'Region 2'),
(15, 'Team O Club', '2020-11-11', 'Region 3'),
(16, 'Team P Club', '2017-06-30', 'Region 1'),
(17, 'Team Q Club', '2018-08-20', 'Region 2'),
(18, 'Team R Club', '2019-02-14', 'Region 3'),
(19, 'Team S Club', '2020-03-03', 'Region 1'),
(20, 'Team T Club', '2021-05-05', 'Region 2');
/* 2024-06-01 23:59:17 [10 ms] */ 
INSERT INTO Team (Name, ClubID, Region, FormationDate) VALUES 
('Team A1', 1, 'Region 1', '2020-01-15'),
('Team A2', 1, 'Region 1', '2020-02-20'),
('Team B1', 2, 'Region 2', '2019-06-01'),
('Team B2', 2, 'Region 2', '2019-07-15'),
('Team C1', 3, 'Region 3', '2018-04-01'),
('Team C2', 3, 'Region 3', '2018-05-10'),
('Team D1', 4, 'Region 1', '2021-04-15'),
('Team D2', 4, 'Region 1', '2021-05-20'),
('Team E1', 5, 'Region 2', '2017-12-10'),
('Team E2', 5, 'Region 2', '2018-01-25'),
('Team F1', 6, 'Region 3', '2019-09-10'),
('Team F2', 6, 'Region 3', '2019-10-30'),
('Team G1', 7, 'Region 1', '2020-10-01'),
('Team G2', 7, 'Region 1', '2020-11-15'),
('Team H1', 8, 'Region 2', '2018-08-01'),
('Team H2', 8, 'Region 2', '2018-09-15'),
('Team I1', 9, 'Region 3', '2017-11-01'),
('Team I2', 9, 'Region 3', '2017-12-15'),
('Team J1', 10, 'Region 1', '2019-12-20'),
('Team J2', 10, 'Region 1', '2020-01-30');
/* 2024-06-01 23:59:18 [12 ms] */ 
INSERT INTO Member (TeamName, Name, Role, Nationality, JoinDate, Age) VALUES 
('Team A1', 'Alice', 'Player', 'Country 1', '2020-02-01', 20),
('Team A2', 'Aaron', 'Coach', 'Country 1', '2020-03-01', 35),
('Team B1', 'Bob', 'Player', 'Country 2', '2019-07-01', 22),
('Team B2', 'Brian', 'Coach', 'Country 2', '2019-08-01', 36),
('Team C1', 'Charlie', 'Player', 'Country 3', '2018-05-01', 25),
('Team C2', 'Cathy', 'Coach', 'Country 3', '2018-06-01', 34),
('Team D1', 'David', 'Player', 'Country 4', '2021-05-01', 23),
('Team D2', 'Diana', 'Coach', 'Country 4', '2021-06-01', 33),
('Team E1', 'Eve', 'Player', 'Country 5', '2017-12-15', 24),
('Team E2', 'Edward', 'Coach', 'Country 5', '2018-02-01', 37),
('Team F1', 'Frank', 'Player', 'Country 6', '2019-10-01', 26),
('Team F2', 'Fiona', 'Coach', 'Country 6', '2019-11-01', 32),
('Team G1', 'George', 'Player', 'Country 7', '2020-10-15', 27),
('Team G2', 'Grace', 'Coach', 'Country 7', '2020-12-01', 31),
('Team H1', 'Hank', 'Player', 'Country 8', '2018-08-15', 28),
('Team H2', 'Helen', 'Coach', 'Country 8', '2018-10-01', 30),
('Team I1', 'Ian', 'Player', 'Country 9', '2017-11-15', 29),
('Team I2', 'Ivy', 'Coach', 'Country 9', '2018-01-01', 29),
('Team J1', 'Jack', 'Player', 'Country 10', '2019-12-25', 20),
('Team J2', 'Jill', 'Coach', 'Country 10', '2020-02-01', 35),
('Team A1', 'Anna', 'Player', 'Country 11', '2020-02-01', 21),
('Team A2', 'Andy', 'Player', 'Country 12', '2020-03-01', 22),
('Team B1', 'Bella', 'Player', 'Country 13', '2019-07-01', 23),
('Team B2', 'Ben', 'Player', 'Country 14', '2019-08-01', 24),
('Team C1', 'Cindy', 'Player', 'Country 15', '2018-05-01', 25),
('Team C2', 'Carl', 'Player', 'Country 16', '2018-06-01', 26),
('Team D1', 'Derek', 'Player', 'Country 17', '2021-05-01', 27),
('Team D2', 'Dana', 'Player', 'Country 18', '2021-06-01', 28),
('Team E1', 'Eva', 'Player', 'Country 19', '2017-12-15', 29),
('Team E2', 'Ethan', 'Player', 'Country 20', '2018-02-01', 30),
('Team F1', 'Fred', 'Player', 'Country 21', '2019-10-01', 31),
('Team F2', 'Faith', 'Player', 'Country 22', '2019-11-01', 32),
('Team G1', 'Gary', 'Player', 'Country 23', '2020-10-15', 33),
('Team G2', 'Gina', 'Player', 'Country 24', '2020-12-01', 34),
('Team H1', 'Harry', 'Player', 'Country 25', '2018-08-15', 35),
('Team H2', 'Hannah', 'Player', 'Country 26', '2018-10-01', 36),
('Team I1', 'Isaac', 'Player', 'Country 27', '2017-11-15', 37),
('Team I2', 'Isabel', 'Player', 'Country 28', '2018-01-01', 38),
('Team J1', 'James', 'Player', 'Country 29', '2019-12-25', 39),
('Team J2', 'Jasmine', 'Player', 'Country 30', '2020-02-01', 40);
/* 2024-06-02 17:40:22 [5 ms] */ 
USE CSManagementSystem;
/* 2024-06-02 17:42:17 [17 ms] */ 
CREATE PROCEDURE update_team_region_procedure(
    IN p_team_name VARCHAR(255),
    IN p_club_id INT,
    IN p_new_region VARCHAR(255)
)
BEGIN
    DECLARE region_count INT;
    -- 检查俱乐部是否已有相同区域的队伍
    SELECT COUNT(*) INTO region_count
    FROM Team
    WHERE ClubID = p_club_id AND Region = p_new_region AND Name != p_team_name;

    IF region_count > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'This club already has a team in the specified region';
    ELSE
        -- 更新队伍区域信息
        UPDATE Team
        SET Region = p_new_region
        WHERE Name = p_team_name;
    END IF;
END;
/* 2024-06-02 17:44:55 [16 ms] */ 
CREATE PROCEDURE update_team_region(
    IN p_team_name VARCHAR(255),
    IN p_club_id INT,
    IN p_region VARCHAR(255),
    IN p_formation_date DATE
)
BEGIN
    DECLARE region_count INT;
    
    -- 检查同俱乐部是否有其他队伍在相同区域
    SELECT COUNT(*) INTO region_count 
    FROM Team 
    WHERE ClubID = p_club_id AND Region = p_region AND Name != p_team_name;
    
    IF region_count > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '同俱乐部的队伍不能在相同区域';
    ELSE
        -- 更新队伍信息
        UPDATE Team
        SET ClubID = p_club_id, Region = p_region, FormationDate = p_formation_date
        WHERE Name = p_team_name;
    END IF;
END ;
