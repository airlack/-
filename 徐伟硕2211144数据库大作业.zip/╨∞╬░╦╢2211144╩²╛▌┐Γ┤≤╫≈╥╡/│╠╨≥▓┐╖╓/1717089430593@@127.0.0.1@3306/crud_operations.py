from db_connection import get_db_connection
import mysql.connector
def update_team_region(team_name, club_id, region, formation_date):
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.callproc('update_team_region', (team_name, club_id, region, formation_date))
            connection.commit()
            print("队伍更新成功")
        except mysql.connector.Error as e:
            if e.errno == mysql.connector.errorcode.ER_SIGNAL_EXCEPTION:
                raise mysql.connector.Error(f"存储过程错误: {e.msg}")
            else:
                raise
        finally:
            cursor.close()
            connection.close()
def get_club_members_by_name(club_name):
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("SELECT * FROM ClubMembersView WHERE ClubName = %s", (club_name,))
            results = cursor.fetchall()
            return results
        except mysql.connector.Error as e:
            print(f"获取视图时出错: {e}")
            return []
        finally:
            cursor.close()
            connection.close()

# 查找最小的可用 ClubID
def get_next_club_id():
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("SELECT ClubID FROM Club ORDER BY ClubID")
            rows = cursor.fetchall()
            current_id = 1
            for row in rows:
                if row[0] != current_id:
                    break
                current_id += 1
            return current_id
        except mysql.connector.Error as e:
            print(f"获取 ClubID 时出错: {e}")
            return None
        finally:
            cursor.close()
            connection.close()

# 创建俱乐部
def create_club(name, creation_date, region):
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            club_id = get_next_club_id()
            cursor.execute("INSERT INTO Club (ClubID, Name, CreationDate, Region) VALUES (%s, %s, %s, %s)", (club_id, name, creation_date, region))
            connection.commit()
            print("俱乐部创建成功")
        except mysql.connector.Error as e:
            if e.errno == mysql.connector.errorcode.ER_SIGNAL_EXCEPTION:
                raise mysql.connector.Error(f"触发器错误: {e.msg}")
            else:
                raise
        finally:
            cursor.close()
            connection.close()

def delete_club_with_teams_and_members(club_id):
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            connection.start_transaction()
            cursor.execute("""
                DELETE Member 
                FROM Member
                JOIN Team ON Member.TeamName = Team.Name
                WHERE Team.ClubID = %s
            """, (club_id,))
            cursor.execute("DELETE FROM Team WHERE ClubID = %s", (club_id,))
            cursor.execute("DELETE FROM Club WHERE ClubID = %s", (club_id,))
            connection.commit()
            print("俱乐部及其相关队伍和成员删除成功")
        except mysql.connector.Error as e:
            connection.rollback()
            print(f"删除俱乐部及其相关数据时出错: {e}")
        finally:
            cursor.close()
            connection.close()

# 读取俱乐部信息
def read_clubs():
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("SELECT * FROM Club")
            rows = cursor.fetchall()
            for row in rows:
                print(row)
            return rows
        except mysql.connector.Error as e:
            print(f"读取俱乐部信息时出错: {e}")
            return []
        finally:
            cursor.close()
            connection.close()

# 更新俱乐部信息
def update_club(club_id, name, creation_date, region):
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("UPDATE Club SET Name=%s, CreationDate=%s, Region=%s WHERE ClubID=%s", (name, creation_date, region, club_id))
            connection.commit()
            print("俱乐部更新成功")
        except mysql.connector.Error as e:
            print(f"更新俱乐部时出错: {e}")
        finally:
            cursor.close()
            connection.close()

# 删除俱乐部
def delete_club(club_id):
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("DELETE FROM Club WHERE ClubID=%s", (club_id,))
            connection.commit()
            print("俱乐部删除成功")
        except mysql.connector.Error as e:
            print(f"删除俱乐部时出错: {e}")
        finally:
            cursor.close()
            connection.close()

# 创建队伍
def create_team(name, club_id, region, formation_date):
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("INSERT INTO Team (Name, ClubID, Region, FormationDate) VALUES (%s, %s, %s, %s)", (name, club_id, region, formation_date))
            connection.commit()
            print("队伍创建成功")
        except mysql.connector.Error as e:
            print(f"创建队伍时出错: {e}")
        finally:
            cursor.close()
            connection.close()

# 读取队伍信息
def read_teams():
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("SELECT * FROM Team")
            rows = cursor.fetchall()
            for row in rows:
                print(row)
            return rows
        except mysql.connector.Error as e:
            print(f"读取队伍信息时出错: {e}")
            return []
        finally:
            cursor.close()
            connection.close()

# 更新队伍信息
def update_team(name, club_id, region, formation_date):
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("UPDATE Team SET ClubID=%s, Region=%s, FormationDate=%s WHERE Name=%s", (club_id, region, formation_date, name))
            connection.commit()
            print("队伍更新成功")
        except mysql.connector.Error as e:
            print(f"更新队伍时出错: {e}")
        finally:
            cursor.close()
            connection.close()

# 删除队伍
def delete_team(name):
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("DELETE FROM Team WHERE Name=%s", (name,))
            connection.commit()
            print("队伍删除成功")
        except mysql.connector.Error as e:
            print(f"删除队伍时出错: {e}")
        finally:
            cursor.close()
            connection.close()

def get_next_member_id():
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("SELECT MemberID FROM Member ORDER BY MemberID")
            rows = cursor.fetchall()
            current_id = 1
            for row in rows:
                if row[0] != current_id:
                    break
                current_id += 1
            return current_id
        except mysql.connector.Error as e:
            print(f"获取 MemberID 时出错: {e}")
            return None
        finally:
            cursor.close()
            connection.close()

def create_member(team_name, name, role, nationality, join_date, age):
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            member_id = get_next_member_id()
            cursor.execute("INSERT INTO Member (MemberID, TeamName, Name, Role, Nationality, JoinDate, Age) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                           (member_id, team_name, name, role, nationality, join_date, age))
            connection.commit()
            print("成员创建成功")
        except mysql.connector.Error as e:
            print(f"创建成员时出错: {e}")
        finally:
            cursor.close()
            connection.close()

# 读取成员信息
def read_members():
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("SELECT * FROM Member")
            rows = cursor.fetchall()
            for row in rows:
                print(row)
            return rows
        except mysql.connector.Error as e:
            print(f"读取成员信息时出错: {e}")
            return []
        finally:
            cursor.close()
            connection.close()

# 更新成员信息
def update_member(member_id, team_name, name, role, nationality, join_date, age):
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.callproc('update_member_procedure', (member_id, team_name, name, role, nationality, join_date, age))
            connection.commit()
            print("成员更新成功")
        except mysql.connector.Error as e:
            if e.errno == mysql.connector.errorcode.ER_SIGNAL_EXCEPTION:
                raise mysql.connector.Error(f"过程错误: {e.msg}")
            else:
                raise
        finally:
            cursor.close()
            connection.close()

# 删除成员
def delete_member(member_id):
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("DELETE FROM Member WHERE MemberID=%s", (member_id,))
            connection.commit()
            print("成员删除成功")
        except mysql.connector.Error as e:
            print(f"删除成员时出错: {e}")
        finally:
            cursor.close()
            connection.close()

# 创建比赛
def create_match(date, level):
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("INSERT INTO Matches (Date, Level) VALUES (%s, %s)", (date, level))
            connection.commit()
            print("比赛创建成功")
        except mysql.connector.Error as e:
            print(f"创建比赛时出错: {e}")
        finally:
            cursor.close()
            connection.close()

# 读取比赛信息
def read_matches():
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("SELECT * FROM Matches")
            rows = cursor.fetchall()
            for row in rows:
                print(row)
            return rows
        except mysql.connector.Error as e:
            print(f"读取比赛信息时出错: {e}")
            return []
        finally:
            cursor.close()
            connection.close()

# 更新比赛信息
def update_match(number, date, level):
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("UPDATE Matches SET Date=%s, Level=%s WHERE Number=%s", (date, level, number))
            connection.commit()
            print("比赛更新成功")
        except mysql.connector.Error as e:
            print(f"更新比赛时出错: {e}")
        finally:
            cursor.close()
            connection.close()

# 删除比赛
def delete_match(number):
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("DELETE FROM Matches WHERE Number=%s", (number,))
            connection.commit()
            print("比赛删除成功")
        except mysql.connector.Error as e:
            print(f"删除比赛时出错: {e}")
        finally:
            cursor.close()
            connection.close()

# 创建赞助商
def create_sponsor(name, industry, contact_info):
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("INSERT INTO Sponsor (Name, Industry, ContactInfo) VALUES (%s, %s, %s)", (name, industry, contact_info))
            connection.commit()
            print("赞助商创建成功")
        except mysql.connector.Error as e:
            print(f"创建赞助商时出错: {e}")
        finally:
            cursor.close()
            connection.close()

# 读取赞助商信息
def read_sponsors():
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("SELECT * FROM Sponsor")
            rows = cursor.fetchall()
            for row in rows:
                print(row)
            return rows
        except mysql.connector.Error as e:
            print(f"读取赞助商信息时出错: {e}")
            return []
        finally:
            cursor.close()
            connection.close()

# 更新赞助商信息
def update_sponsor(name, industry, contact_info):
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("UPDATE Sponsor SET Industry=%s, ContactInfo=%s WHERE Name=%s", (industry, contact_info, name))
            connection.commit()
            print("赞助商更新成功")
        except mysql.connector.Error as e:
            print(f"更新赞助商时出错: {e}")
        finally:
            cursor.close()
            connection.close()

# 删除赞助商
def delete_sponsor(name):
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("DELETE FROM Sponsor WHERE Name=%s", (name,))
            connection.commit()
            print("赞助商删除成功")
        except mysql.connector.Error as e:
            print(f"删除赞助商时出错: {e}")
        finally:
            cursor.close()
            connection.close()
