-- 创建数据库
CREATE DATABASE CSManagementSystem;

-- 使用数据库
USE CSManagementSystem;

-- 创建俱乐部表
CREATE TABLE Club (
    ClubID INT PRIMARY KEY,
    Name VARCHAR(255) NOT NULL,
    CreationDate DATE NOT NULL,
    Region VARCHAR(255) NOT NULL
);

-- 创建队伍表
CREATE TABLE Team (
    Name VARCHAR(255) PRIMARY KEY,
    ClubID INT NOT NULL,
    Region VARCHAR(255) NOT NULL,
    FormationDate DATE NOT NULL,
    FOREIGN KEY (ClubID) REFERENCES Club(ClubID)
);

-- 创建成员表
CREATE TABLE Member (
    MemberID INT PRIMARY KEY AUTO_INCREMENT,
    TeamName VARCHAR(255) NOT NULL,
    Name VARCHAR(255) NOT NULL,
    Role VARCHAR(255) NOT NULL,
    Nationality VARCHAR(255) NOT NULL,
    JoinDate DATE NOT NULL,
    Age INT NOT NULL,
    FOREIGN KEY (TeamName) REFERENCES Team(Name)
);

-- 创建比赛表
CREATE TABLE Matches (
    Number INT PRIMARY KEY AUTO_INCREMENT,
    Date DATE NOT NULL,
    Level VARCHAR(255) NOT NULL
);

-- 创建赞助商表
CREATE TABLE Sponsor (
    Name VARCHAR(255) PRIMARY KEY,
    Industry VARCHAR(255) NOT NULL,
    ContactInfo VARCHAR(255) NOT NULL
);

-- 创建首发成员表
CREATE TABLE StartingMember (
    MemberID INT PRIMARY KEY,
    Starts INT NOT NULL,
    StartingPosition VARCHAR(255) NOT NULL,
    FOREIGN KEY (MemberID) REFERENCES Member(MemberID)
);

-- 创建青训成员表
CREATE TABLE YouthMember (
    MemberID INT PRIMARY KEY,
    TrainingLevel VARCHAR(255) NOT NULL,
    YearJoined INT NOT NULL,
    FOREIGN KEY (MemberID) REFERENCES Member(MemberID)
);

-- 创建替补成员表
CREATE TABLE SubstituteMember (
    MemberID INT PRIMARY KEY,
    SubstituteAppearances INT NOT NULL,
    FOREIGN KEY (MemberID) REFERENCES Member(MemberID)
);

-- 创建赞助关系表
CREATE TABLE Sponsorship (
    SponsorName VARCHAR(255),
    ClubID INT,
    PRIMARY KEY (SponsorName, ClubID),
    FOREIGN KEY (SponsorName) REFERENCES Sponsor(Name),
    FOREIGN KEY (ClubID) REFERENCES Club(ClubID)
);

-- 创建比赛参与表
CREATE TABLE MatchParticipation (
    MatchNumber INT,
    TeamName VARCHAR(255),
    PRIMARY KEY (MatchNumber, TeamName),
    FOREIGN KEY (MatchNumber) REFERENCES Matches(Number),
    FOREIGN KEY (TeamName) REFERENCES Team(Name)
);

-- 创建视图
CREATE VIEW ClubMembersView AS
SELECT 
    Club.Name AS ClubName,
    Member.Name AS MemberName,
    Member.Role AS MemberRole
FROM 
    Club
JOIN 
    Team ON Club.ClubID = Team.ClubID
JOIN 
    Member ON Team.Name = Member.TeamName;

-- 创建触发器
DELIMITER //
CREATE TRIGGER before_club_insert
BEFORE INSERT ON Club
FOR EACH ROW
BEGIN
    DECLARE name_count INT;
    SELECT COUNT(*) INTO name_count FROM Club WHERE Name = NEW.Name;
    IF name_count > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Club name must be unique';
    END IF;
END //
DELIMITER ;

-- 创建存储过程
DELIMITER //
CREATE PROCEDURE update_member_procedure(
    IN p_member_id INT,
    IN p_team_name VARCHAR(255),
    IN p_name VARCHAR(255),
    IN p_role VARCHAR(255),
    IN p_nationality VARCHAR(255),
    IN p_join_date DATE,
    IN p_age INT
)
BEGIN
    -- 检查选手年龄是否超过40岁
    IF p_age > 40 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Player age cannot be greater than 40';
    ELSE
        -- 更新选手信息
        UPDATE Member
        SET TeamName = p_team_name, Name = p_name, Role = p_role, Nationality = p_nationality, JoinDate = p_join_date, Age = p_age
        WHERE MemberID = p_member_id;
    END IF;
END //
DELIMITER ;
-- 插入初始数据示例

-- 插入俱乐部数据
INSERT INTO Club (ClubID, Name, CreationDate, Region) VALUES 
(1, 'Team A Club', '2020-01-01', 'Region 1'),
(2, 'Team B Club', '2019-05-15', 'Region 2');

-- 插入队伍数据
INSERT INTO Team (Name, ClubID, Region, FormationDate) VALUES 
('Team A', 1, 'Region 1', '2020-01-15'),
('Team B', 2, 'Region 2', '2019-06-01');

-- 插入成员数据
INSERT INTO Member (TeamName, Name, Role, Nationality, JoinDate, Age) VALUES 
('Team A', 'Alice', 'Player', 'Country 1', '2020-02-01', 20),
('Team B', 'Bob', 'Player', 'Country 2', '2019-07-01', 22);
