from flask import Flask, render_template, request, redirect, url_for, flash, session
from crud_operations import (
    create_club, read_clubs, update_club, delete_club_with_teams_and_members,
    create_team, read_teams, update_team, delete_team,
    create_member, read_members, update_member, delete_member,
    create_match, read_matches, update_match, delete_match,
    create_sponsor, read_sponsors, update_sponsor, delete_sponsor,
    get_club_members_by_name,update_team_region
)
import mysql.connector

app = Flask(__name__)
app.secret_key = 'Tsh347zl03'

@app.route('/', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'root' and password == 'password':
            session['admin'] = True
            return redirect(url_for('index'))
        else:
            error = '无效的凭证，请重试。'
    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    session.pop('admin', None)
    return redirect(url_for('login'))

@app.route('/index')
def index():
    if not session.get('admin'):
        return redirect(url_for('login'))
    clubs = read_clubs()
    return render_template('index.html', clubs=clubs)

@app.route('/add_club', methods=['GET', 'POST'])
def add_club():
    if not session.get('admin'):
        return redirect(url_for('login'))
    if request.method == 'POST':
        name = request.form['name']
        creation_date = request.form['creation_date']
        region = request.form['region']
        try:
            create_club(name, creation_date, region)
            flash('俱乐部添加成功！')
        except mysql.connector.Error as e:
            flash(f'错误: {e.msg}')
        return redirect(url_for('add_club'))
    return render_template('add_club.html')

@app.route('/view_club_members', methods=['GET', 'POST'])
def view_club_members():
    if not session.get('admin'):
        return redirect(url_for('login'))
    club_members = []
    if request.method == 'POST':
        club_name = request.form['club_name']
        club_members = get_club_members_by_name(club_name)
    return render_template('view_club_members.html', club_members=club_members)

@app.route('/update_club/<int:club_id>', methods=['GET', 'POST'])
def update_club_route(club_id):
    if request.method == 'POST':
        name = request.form['name']
        creation_date = request.form['creation_date']
        region = request.form['region']
        update_club(club_id, name, creation_date, region)
        flash('俱乐部更新成功！')
        return redirect(url_for('index'))
    club = [club for club in read_clubs() if club[0] == club_id][0]
    return render_template('update_club.html', club=club)

@app.route('/delete_club/<int:club_id>', methods=['POST'])
def delete_club_route(club_id):
    delete_club_with_teams_and_members(club_id)
    flash('俱乐部及其相关队伍和成员删除成功！')
    return redirect(url_for('index'))

@app.route('/teams')
def teams():
    teams = read_teams()
    return render_template('teams.html', teams=teams)

@app.route('/add_team', methods=['GET', 'POST'])
def add_team():
    if request.method == 'POST':
        name = request.form['name']
        club_id = request.form['club_id']
        region = request.form['region']
        formation_date = request.form['formation_date']
        create_team(name, club_id, region, formation_date)
        flash('队伍添加成功！')
        return redirect(url_for('teams'))
    return render_template('add_team.html')


@app.route('/delete_team/<string:name>', methods=['POST'])
def delete_team_route(name):
    delete_team(name)
    flash('队伍删除成功！')
    return redirect(url_for('teams'))
@app.route('/update_team/<string:name>', methods=['GET', 'POST'])
def update_team_route(name):
    if request.method == 'POST':
        club_id = request.form['club_id']
        region = request.form['region']
        formation_date = request.form['formation_date']
        try:
            update_team_region(name, club_id, region, formation_date)
            flash('队伍更新成功！')
        except mysql.connector.Error as e:
            flash(f'错误: {e.msg}')
        return redirect(url_for('update_team_route', name=name))
    team = [team for team in read_teams() if team[0] == name][0]
    return render_template('update_team.html', team=team)
@app.route('/members')
def members():
    members = read_members()
    return render_template('members.html', members=members)

@app.route('/add_member', methods=['GET', 'POST'])
def add_member():
    if request.method == 'POST':
        team_name = request.form['team_name']
        name = request.form['name']
        role = request.form['role']
        nationality = request.form['nationality']
        join_date = request.form['join_date']
        age = request.form['age']
        try:
            create_member(team_name, name, role, nationality, join_date, age)
            flash('成员添加成功！')
        except mysql.connector.Error as e:
            flash(f'错误: {e.msg}')
        return redirect(url_for('add_member'))
    return render_template('add_member.html')

@app.route('/update_member/<int:member_id>', methods=['GET', 'POST'])
def update_member_route(member_id):
    if request.method == 'POST':
        team_name = request.form['team_name']
        name = request.form['name']
        role = request.form['role']
        nationality = request.form['nationality']
        join_date = request.form['join_date']
        age = request.form['age']
        try:
            update_member(member_id, team_name, name, role, nationality, join_date, age)
            flash('成员更新成功！')
        except mysql.connector.Error as e:
            flash(f'错误: {e.msg}')
        return redirect(url_for('update_member_route', member_id=member_id))
    member = [member for member in read_members() if member[0] == member_id][0]
    return render_template('update_member.html', member=member)

@app.route('/delete_member/<int:member_id>', methods=['POST'])
def delete_member_route(member_id):
    delete_member(member_id)
    flash('成员删除成功！')
    return redirect(url_for('members'))

@app.route('/matches')
def matches():
    matches = read_matches()
    return render_template('matches.html', matches=matches)

@app.route('/add_match', methods=['GET', 'POST'])
def add_match():
    if request.method == 'POST':
        date = request.form['date']
        level = request.form['level']
        try:
            create_match(None, date, level)  # number is automatically generated
            flash('比赛添加成功！')
        except mysql.connector.Error as e:
            flash(f'错误: {e.msg}')
        return redirect(url_for('matches'))
    return render_template('add_match.html')

@app.route('/update_match/<int:number>', methods=['GET', 'POST'])
def update_match_route(number):
    if request.method == 'POST':
        date = request.form['date']
        level = request.form['level']
        update_match(number, date, level)
        flash('比赛更新成功！')
        return redirect(url_for('matches'))
    match = [match for match in read_matches() if match[0] == number][0]
    return render_template('update_match.html', match=match)

@app.route('/delete_match/<int:number>', methods=['POST'])
def delete_match_route(number):
    delete_match(number)
    flash('比赛删除成功！')
    return redirect(url_for('matches'))

@app.route('/sponsors')
def sponsors():
    sponsors = read_sponsors()
    return render_template('sponsors.html', sponsors=sponsors)

@app.route('/add_sponsor', methods=['GET', 'POST'])
def add_sponsor():
    if request.method == 'POST':
        name = request.form['name']
        industry = request.form['industry']
        contact_info = request.form['contact_info']
        create_sponsor(name, industry, contact_info)
        flash('赞助商添加成功！')
        return redirect(url_for('sponsors'))
    return render_template('add_sponsor.html')

@app.route('/update_sponsor/<string:name>', methods=['GET', 'POST'])
def update_sponsor_route(name):
    if request.method == 'POST':
        industry = request.form['industry']
        contact_info = request.form['contact_info']
        update_sponsor(name, industry, contact_info)
        flash('赞助商更新成功！')
        return redirect(url_for('sponsors'))
    sponsor = [sponsor for sponsor in read_sponsors() if sponsor[0] == name][0]
    return render_template('update_sponsor.html', sponsor=sponsor)

@app.route('/delete_sponsor/<string:name>', methods=['POST'])
def delete_sponsor_route(name):
    delete_sponsor(name)
    flash('赞助商删除成功！')
    return redirect(url_for('sponsors'))

if __name__ == '__main__':
    app.run(debug=True)
