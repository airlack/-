from db_connection import get_db_connection
import mysql.connector

def insert_initial_data():
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            # 插入俱乐部数据
            cursor.execute("INSERT INTO Club (ClubID, Name, CreationDate, Region) VALUES (1, '俱乐部A', '2020-01-01', '区域1')")
            cursor.execute("INSERT INTO Club (ClubID, Name, CreationDate, Region) VALUES (2, '俱乐部B', '2019-05-15', '区域2')")

            # 插入队伍数据
            cursor.execute("INSERT INTO Team (Name, ClubID, Region, FormationDate) VALUES ('队伍A', 1, '区域1', '2020-01-15')")
            cursor.execute("INSERT INTO Team (Name, ClubID, Region, FormationDate) VALUES ('队伍B', 2, '区域2', '2019-06-01')")

            # 插入成员数据
            cursor.execute("INSERT INTO Member (MemberID, TeamName, Name, Role, Nationality, JoinDate, Age) VALUES (1, '队伍A', 'Alice', '选手', '国家1', '2020-02-01', 20)")
            cursor.execute("INSERT INTO Member (MemberID, TeamName, Name, Role, Nationality, JoinDate, Age) VALUES (2, '队伍B', 'Bob', '选手', '国家2', '2019-07-01', 22)")

            # 插入比赛数据
            cursor.execute("INSERT INTO Matches (Date, Level) VALUES ('2021-08-20', '高级')")
            cursor.execute("INSERT INTO Matches (Date, Level) VALUES ('2021-09-15', '中级')")

            # 插入赞助商数据
            cursor.execute("INSERT INTO Sponsor (Name, Industry, ContactInfo) VALUES ('赞助商A', '行业1', '联系方式1')")
            cursor.execute("INSERT INTO Sponsor (Name, Industry, ContactInfo) VALUES ('赞助商B', '行业2', '联系方式2')")

            # 插入首发成员数据
            cursor.execute("INSERT INTO StartingMember (MemberID, Starts, StartingPosition) VALUES (1, 10, '前锋')")
            cursor.execute("INSERT INTO StartingMember (MemberID, Starts, StartingPosition) VALUES (2, 8, '后卫')")

            # 插入青训成员数据
            cursor.execute("INSERT INTO YouthMember (MemberID, TrainingLevel, YearJoined) VALUES (1, '高级', 2020)")
            cursor.execute("INSERT INTO YouthMember (MemberID, TrainingLevel, YearJoined) VALUES (2, '中级', 2019)")

            # 插入替补成员数据
            cursor.execute("INSERT INTO SubstituteMember (MemberID, SubstituteAppearances) VALUES (1, 5)")
            cursor.execute("INSERT INTO SubstituteMember (MemberID, SubstituteAppearances) VALUES (2, 3)")

            # 插入赞助关系数据
            cursor.execute("INSERT INTO Sponsorship (SponsorName, ClubID) VALUES ('赞助商A', 1)")
            cursor.execute("INSERT INTO Sponsorship (SponsorName, ClubID) VALUES ('赞助商B', 2)")

            # 插入比赛参与数据
            cursor.execute("INSERT INTO MatchParticipation (MatchNumber, TeamName) VALUES (1, '队伍A')")
            cursor.execute("INSERT INTO MatchParticipation (MatchNumber, TeamName) VALUES (2, '队伍B')")

            connection.commit()
            print("Initial data inserted successfully!")
        except mysql.connector.Error as e:
            print(f"Error while inserting data: {e}")
        finally:
            cursor.close()
            connection.close()

if __name__ == '__main__':
    insert_initial_data()
