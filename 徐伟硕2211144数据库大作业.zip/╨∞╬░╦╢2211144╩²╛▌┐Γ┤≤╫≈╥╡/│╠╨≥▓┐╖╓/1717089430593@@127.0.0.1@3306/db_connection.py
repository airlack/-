import mysql.connector
from mysql.connector import Error

def get_db_connection():
    try:
        connection = mysql.connector.connect(
            host='127.0.0.1',  # 数据库服务器地址
            user='root',  # 数据库用户名
            password='Tsh347zl03',  # 数据库密码
            database='CSManagementSystem'  # 数据库名称
        )
        if connection.is_connected():
            print("Successfully connected to the database")
            return connection
    except Error as e:
        print(f"Error while connecting to MySQL: {e}")
        return None

if __name__ == '__main__':
    conn = get_db_connection()
    if conn:
        conn.close()