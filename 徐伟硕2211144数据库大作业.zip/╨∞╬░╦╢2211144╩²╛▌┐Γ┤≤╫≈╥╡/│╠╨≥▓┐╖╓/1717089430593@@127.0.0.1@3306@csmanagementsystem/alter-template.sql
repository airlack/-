-- Active: 1717089430593@@127.0.0.1@3306@csmanagementsystem
ALTER TABLE `club` 
	CHANGE ``Region`` ``Region`` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL ;