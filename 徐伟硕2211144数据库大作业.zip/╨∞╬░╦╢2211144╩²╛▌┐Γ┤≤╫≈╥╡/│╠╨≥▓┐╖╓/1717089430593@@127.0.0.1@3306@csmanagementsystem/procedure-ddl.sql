-- Active: 1717089430593@@127.0.0.1@3306@csmanagementsystem
DROP PROCEDURE update_team_region_procedure;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_team_region_procedure`(
    IN p_team_name VARCHAR(255),
    IN p_club_id INT,
    IN p_new_region VARCHAR(255)
)
BEGIN
    DECLARE region_count INT;
    -- 检查俱乐部是否已有相同区域的队伍
    SELECT COUNT(*) INTO region_count
    FROM Team
    WHERE ClubID = p_club_id AND Region = p_new_region AND Name != p_team_name;

    IF region_count > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'This club already has a team in the specified region';
    ELSE
        -- 更新队伍区域信息
        UPDATE Team
        SET Region = p_new_region
        WHERE Name = p_team_name;
    END IF;
END